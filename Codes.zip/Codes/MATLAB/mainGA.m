% Read x and y from an input file containig expression values and categories
% x: m-by-n numeric matrix of expression values of n miRNAs across m samples 
% y: m-by-1 vector of 0 and 1s representing classes of samples (binary classification)

global x_train
global x_test

global y_train
global y_test

N = 5;
K = 5;
nvars = size(x,2);
LB = zeros(1,nvars);
UB = ones(1,nvars);
out = zeros(N*K,nvars);
fval = ones(N*K,1);
% acc = zeros(N*K,1);
% sen = zeros(N*K,1);
% spe = zeros(N*K,1);
res_all = [];
signature = [];
count = 1;
%cp = cell(N*K,1);
for j = 1:N
    global results
    results = [];
    global miRs 
    miRs = [];
    count
    Indices = crossvalind('Kfold', size(x,1), K);
    for i = 1:K
    x_train = x(find(Indices~=i),:);
    x_test  = x(find(Indices==i),:);
    y_train = y(find(Indices~=i),:);
    y_test  = y(find(Indices==i),:);
    
    options = optimoptions('ga','MaxGenerations', 50, 'MaxStallGenerations', 10, 'PopulationSize', 200, 'Display', 'iter', 'FitnessLimit',0);%'UseParallel', true, 'UseVectorized', false,
    [out(count,:), fval(count,1)] = ga(@singleObjective,nvars,[],[],[],[],LB,UB,[],1:nvars,options);
   
    [~,Locb] = ismember(out(count,:),miRs,'rows');
    res_all = [res_all;results(Locb,:)];
    signature = [signature;miRs(Locb,:)];
     
    count = count+1;

    end
end

save('.\GA.mat','res_all','signature');

