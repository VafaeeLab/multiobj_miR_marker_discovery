function [ f ] = multiObjective( selectedIDs )
if(sum(selectedIDs) < 1)
    f = 100*ones(1,2); 
else
    f = zeros(1,2);
    f(1) = singleObjective(selectedIDs);
    f(2) = 1/FR(selectedIDs);
end

