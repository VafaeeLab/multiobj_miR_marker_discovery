function [err] = singleObjective( selectedMiRs)
global x_train
global y_train
global results
global miRs
xtrain = x_train(:,logical(selectedMiRs));
ytrain = y_train;
 
 
SVMModel = fitcsvm(xtrain,ytrain);
CVSVMModel = crossval(SVMModel, 'kfold', 5);
pred = kfoldPredict(CVSVMModel);
  
cp = classperf(ytrain, pred);
err = cp.ErrorRate;

%to test on the same model 

global x_test
global y_test

xtest = x_test(:,logical(selectedMiRs));
ytest = y_test;

pred = predict(SVMModel,xtest);
acc =  1- immse(pred, ytest);
sen = 1- immse(pred(logical(ytest),1), ytest(logical(ytest),1));
if isempty(ytest(~logical(ytest),1))
    spe = 0;
else
    spe = 1- immse(pred(~logical(ytest),1), ytest(~logical(ytest),1));
end

results = [results; [cp.CorrectRate, cp.Sensitivity, cp.Specificity, acc,sen,spe]];
miRs = [miRs; selectedMiRs];
end

