% Read x and y from an input file containig expression values and categories
% x: m-by-n numeric matrix of expression values of n miRNAs across m samples 
% y: m-by-1 vector of 0 and 1s representing classes of samples (binary classification)
% FR scores outputed by R script. FR is a numeric vector of n-by-1 containig FR score of each miRNA

global funcScore
funcScore = FR;

global x_train
global x_test

global y_train
global y_test

N = 5;
K = 5;
nvars = size(x,2);
LB = zeros(1,nvars);
UB = ones(1,nvars);
out = zeros(N*K,nvars);
fval = ones(N*K,1);
res_all = [];
signature = [];
count = 1;
Cfval = cell(N*K,1);
Cout = cell(N*K,1);
for j = 1:N
    global results
    results = [];
    global miRs 
    miRs = [];
    Indices = crossvalind('Kfold', size(x,1), K);
    for i = 1:K
    count
    x_train = x(find(Indices~=i),:);
    x_test  = x(find(Indices==i),:);
    y_train = y(find(Indices~=i),:);
    y_test  = y(find(Indices==i),:);
    
    options = optimoptions('gamultiobj','PopulationType', 'bitstring','MaxGenerations', 50, 'MaxStallGenerations', 10, 'PopulationSize', 200, 'Display', 'iter');%'UseParallel', true, 'UseVectorized', false,
    [out,fval] = gamultiobj(@multiObjective,nvars,[],[],[],[],LB,UB,[],options);
    
    for l = 1:size(fval,1)
        [~,Locb] = ismember(out(l,:),miRs,'rows');
        res_all = [res_all;results(Locb,:)];
        signature = [signature;miRs(Locb,:)];
    end
    Cfval{count,1} = fval;
    Cout{count,1} = out;
    
    count = count+1;

    end
end

save('.\multiGA.mat','res_all','signature', 'Cout','Cfval');

