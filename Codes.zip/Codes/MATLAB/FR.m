function [ f2 ] = FR( selectedIDs )

global funcScore 

if max(selectedIDs)
     selected = funcScore(logical(selectedIDs));
     f2 = mean(selected);
else
    f2 = 0.0001;
end
end



