
# Retrieve miR-TGs from MultiMiR ------------------------------------------
library(multiMiR) # For installation guide see: http://multimir.ucdenver.edu/

miRs = read.table(file = "./miRs.txt", header = FALSE) # Read list of miRNAs

miRsTG.val  = get_multimir(mirna=miRs, summary=TRUE, table = "validated", org = 'hsa')
miRsTG.pred = get_multimir(mirna=miRs, summary=TRUE, table = "predicted", org = 'hsa')
miRsTG.pred = subset(miRsTG.pred@summary, all.sum > 1)

miRsTG.pred.net = subset(miRsTG.pred, select = c(mature_mirna_id, target_symbol))
miRsTG.pred.net = subset(miRsTG.pred.net, target_symbol!= '')

miRsTG.val.net = subset(miRsTG.val@summary, select = c(mature_mirna_id, target_symbol))
miRsTG.val.net = subset(miRsTG.val.net, target_symbol!= '')

miRsTG.net = unique.array(rbind(miRsTG.pred.net, miRsTG.val.net))


# Build miR-mediated Regulatory network -----------------------------------
orti = read.table(file = "./rev2/data/ORTI.txt", header = TRUE) 
# miRsTG.net = read.table(file = "./rev2/data/mir-tg.txt", header = TRUE)

colnames(miRsTG.net) = c("TF","TG") # make columns identical with orti 
net = miRsTG.net

visited = c()
tfs = as.character(unique(intersect(miRsTG.net$TG,orti$TF)))
while(length(tfs)>0){
  tf = tfs[1]
  tgs = unique(orti[which(orti$TF==tf),2])
  keep = !(tgs  %in% visited)& tgs %in% orti$TF
  tfs = c(tfs,tgs[keep])
  tf.tg = unique(orti[which(orti$TF==tf),])
  
  net = rbind(net,tf.tg)
  visited = c(visited,tf)
  tfs  = tfs[-1]
  cat("\n",tf,"\t",length(visited),"\t",length(tfs))
}

# Compute functional relevance for each miRNA -----------------------------
library(igraph)
# net = read.table(file = "./rev2/data/net.txt", header = TRUE)
genes = read.table(file = "./rev2/data/genes-Breast.txt", header = TRUE)
g <- graph_from_edgelist(as.matrix(net), directed = TRUE)
nodes = vertex_attr(g)[1]$name


epsilon = 0.001
FR = c()
for(m in miRs[,1]){
  if(m %in% nodes){
      d =  distances(g, v = m, to = genes$Gene, mode = "out")
      fr = epsilon + sum(exp(-1*(d+genes$Rank)))
      FR = rbind(FR,cbind(m,fr))
  }
  else{
    FR = rbind(FR,cbind(m,epsilon))
  }
}
colnames(FR) <- c("miRNA","FR")
write.table(FR, file = "./FR.txt", quote = FALSE, sep = "\t", row.names = FALSE)
